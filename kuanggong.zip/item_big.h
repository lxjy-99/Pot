#ifndef ITEM_BIG_H
#define ITEM_BIG_H

class Item_Big
{
public:
    Item_Big();
};

#endif // ITEM_BIG_H
