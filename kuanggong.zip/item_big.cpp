﻿#ifndef ITEM_BIG_H
#define ITEM_BIG_H
#include"item.h"
class Item_Big:public Item
{
public:
    Item_Big();
    void init();
};

#endif // ITEM_SMALL_H
