#ifndef ITEM_SMALL_H
#define ITEM_SMALL_H
#include"item.h"
class Item_Small:public Item
{
public:
    Item_Small();
    void init();
};

#endif // ITEM_SMALL_H
